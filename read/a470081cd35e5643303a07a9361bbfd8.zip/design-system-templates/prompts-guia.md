# Guía de prompts para Copilot — Design System

Este archivo no es parte del sistema de diseño sino una ayuda para el alumnado.
Recoge los prompts recomendados para cada fase del desarrollo.

---

## Fase 1 — Generar tokens.css desde los .md

```
Lee los archivos colors.md, typography.md y spacing.md de la carpeta /docs
y genera el archivo tokens.css con todos los custom properties CSS definidos
en las tablas. Agrupa los tokens por secciones con comentarios:
/* Colors */, /* Typography */, /* Spacing */, /* Radius */, /* Shadows */.
No uses ningún valor fijo en el resto del CSS: todo debe referenciar un token.
```

---

## Fase 2 — Generar el CSS base de componentes

```
Lee el archivo components.md y genera el CSS de los componentes usando
exclusivamente los tokens de tokens.css. Empieza por los botones.
Cuando termines muéstramelos y espera mi validación antes de continuar
con el siguiente componente.
```

---

## Fase 3 — Generar una página completa

```
Genera el HTML de la página [nombre] usando la estructura del wireframe
que te describo a continuación: [descripción]. Usa los componentes
definidos en components.md y los tokens de tokens.css. El HTML debe
importar tokens.css y main.css. Nada de estilos inline.
```

---

## Fase 4 — Revisar coherencia visual

```
Revisa el archivo main.css y comprueba que no hay ningún valor
de color, tamaño de fuente o espaciado fijo (como #333333 o 16px).
Todo debe usar custom properties de tokens.css. Lista los casos
que encuentres y corrígelos.
```

---

## Regla de oro

Si Copilot genera código que no entiendes: pídele que te lo explique línea a línea.
Si sigue sin quedar claro: pídele una versión más simple.
Nunca incluyas en tu proyecto código que no seas capaz de explicar.
